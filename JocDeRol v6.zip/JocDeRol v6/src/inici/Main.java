package inici;

import jdk.swing.interop.SwingInterOpUtils;
import joc.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void Part3() {
        Warriors huma1 = new Warriors("Raül", 16, 5, 900);
        Alien alien1 = new Alien("ET", 6, 2, 30);
        Human alien2 = new Human("ruben", 60, 20, 300);
        alien2.attack(huma1);
    }

    public static void Part4() {
        Alien ELM = new Alien("elm", 0, 2, 3);
        Warriors ELMO = new Warriors("elm", 0, 2, 3);
        Team reven = new Team("els reven");
        ELM.add(reven);
        reven.tString();
        ELM.delete(reven);
        reven.tString();
        ELM.equals(ELMO);

    }

    public static void Part5() {
        Alien ELM = new Alien("elm", 0, 2, 3);
        Warriors ELMO = new Warriors("elm", 0, 2, 3);
        Team reven = new Team("els reven");
        Item sun = new Item("sunglasses", 12, 13);
        Item suni = new Item("sunglasse", 0, 0);
        System.out.println(ELM);
        ELM.additem(sun);
        System.out.println(ELM);
        ELM.additem(suni);
        System.out.println(ELM);
    }

    public static void crearjugador(camara cam) {
        System.out.println("donam el nom de el jugadors");
        Scanner opcions = new Scanner(System.in);
        String NOM = opcions.nextLine();
        System.out.println("donam el el tipus de jugador (A, W, P, Z)");
        String tipo = opcions.nextLine();
        System.out.println("Donam el valor dels PA , tin en conter que cuants mes PA tinga el teu personatge menys de defensa tindra");
        int PA = opcions.nextInt();
        int PD = 100 - PA;
        switch (tipo) {
            case "A" -> {
                cam.addplayer(new Alien(NOM, PA, PD, 100));
                cam.tString();
                System.out.println("JUGADOR GENERAT");
            }
            case "Z" -> {
                cam.addplayer(new Zombie(NOM, PA, PD, 100));
                cam.tString();
                System.out.println("JUGADOR GENERAT");
            }
            case "H" -> {
                cam.addplayer(new Human(NOM, PA, PD, 100));
                cam.tString();
                System.out.println("JUGADOR GENERAT");
            }
            case "W" -> {
                cam.addplayer(new Warriors(NOM, PA, PD, 100));
                cam.tString();
                System.out.println("JUGADOR GENERAT");
            }
        }
    }

    public static void crearequip(camara cam) {
        System.out.println("donam el nom de el equip que vols crear");
        Scanner opcions = new Scanner(System.in);
        String NOM = opcions.nextLine();
        cam.addteam(new Team(NOM));
    }

    public static void esborrarjugadors(camara cam) {
        System.out.println("Donam el nom del jugador que vols borrar");
        Scanner opcion = new Scanner(System.in);
        String NOM = opcion.nextLine();
        cam.delplayer(NOM);
        System.out.println("JUGADOR BORRAT :(F");

    }

    public static Player traureEq(String nom, camara cam) {
        int i = 0;
        if (cam.getJugadors().size() != 0) {

            while (i != cam.getJugadors().size()) {
                if (cam.getJugadors().get(i).getNom().equals(nom)) {
                    return cam.getJugadors().get(i);

                }
                if (i + 1 == cam.getJugadors().size()) {
                    break;
                }
                i = i + 1;
            }
        }
        System.out.println("No se ha trobat el nom");
        return null;
    }

    public static Team traureTe(String nom2, camara cam) {
        int i = -1;
        if (cam.getPlayers2().size() != 0) {

            while (i != cam.getPlayers2().size()) {
                i = i + 1;
                if (cam.getPlayers2().get(i).getName().equals(nom2)) {
                    return cam.getPlayers2().get(i);

                }
                if (i + 1 == cam.getPlayers2().size()) {
                    break;
                }
            }
        }
        System.out.println("No se ha trobat el nom");
        return null;
    }

    public static Item traureIT(String nom2, camara cam) {
        int i = -1;
        if (cam.getItems().size() != 0) {

            while (i != cam.getItems().size()) {
                i = i + 1;
                if (cam.getItems().get(i).getNom().equals(nom2)) {
                    return cam.getItems().get(i);

                }
                if (i + 1 == cam.getItems().size()) {
                    break;
                }
            }
        }
        System.out.println("No se ha trobat el nom");
        return null;
    }

    public static void esborrarequips(camara cam) {
        System.out.println("Donam el nom del equip que vols borrar");
        Scanner opcion = new Scanner(System.in);
        String NOM = opcion.nextLine();
        cam.delequip(NOM);
        System.out.println("EQUIP BORRAT :(F");
    }

    public static void esborraritems(camara cam) {
        System.out.println("Donam el nom del item que vols borrar");
        Scanner opcion = new Scanner(System.in);
        String NOM = opcion.nextLine();
        cam.delitem(NOM);
        System.out.println("ITEM BORRAT :(F");
    }

    public static void jugequi(camara cam) {
        System.out.println("Donam el nom del jugador que vols que entre al equip");
        Scanner opcion = new Scanner(System.in);
        String NOM = opcion.nextLine();
        System.out.println("Donam el nom del equip");
        String NOM2 = opcion.nextLine();
        Team TEAM = traureTe(NOM, cam);
        Player PLAYER = traureEq(NOM2, cam);
        PLAYER.add(TEAM);
    }


    public static void itemequi(camara cam) {
        System.out.println("Donam el nom del jugador que vols que tinga el item");
        Scanner opcion = new Scanner(System.in);
        String NOM = opcion.nextLine();
        System.out.println("Donam el nom del item");
        String NOM2 = opcion.nextLine();
        Player PLAYER = traureEq(NOM, cam);
        Item item = traureIT(NOM2, cam);
        PLAYER.additem(item);

    }

    public static void menuJUGADORS(camara cam,File a) {
        System.out.println("1.2.1 Crear JUGADORS\n1.2.2 Mostrar JUGADORS\n1.2.3 Esborrar JUGADORS\n1.2.4 Assignar equip a jugador\n1.2.5Assignar item a jugador\n1.2.6  Eixir");
        Scanner opcio = new Scanner(System.in);
        int nummenu = 4;
        int op = opcio.nextInt();
        switch (op) {
            case 1:
                if (op == 1)
                    crearjugador(cam);
            case 2:
                if (op == 2)
                    cam.tString();
            case 3:
                if (op == 3)
                    esborrarjugadors(cam);
            case 4:
                if (op == 4)
                    jugequi(cam);
            case 5:
                if (op == 5)
                    itemequi(cam);
            case 6:
                if (op == 5)
                    menu2(cam,a);
        }
    }

    public static void crearitem(camara cam) {
        System.out.println("donam el nom de el item");
        Scanner opcions = new Scanner(System.in);
        String NOM = opcions.nextLine();
        System.out.println("Donam el valor dels PA bonus que dona el objecte");
        int PA = opcions.nextInt();
        System.out.println("Donam el valor dels PD bonus que dona el objecte");
        int PD = opcions.nextInt();
        cam.additem(new Item(NOM, PA, PD));

    }

    public static void menuEquips(camara cam,File a) {
        System.out.println("1.2.1 Crear equip\n1.2.2 Mostrar equips\n1.2.3 Esborrar equip\n1.2.4 Assignar equip a jugador\n1.1.5  Eixir");
        Scanner opcio = new Scanner(System.in);
        int nummenu = 4;
        int op = opcio.nextInt();
        switch (op) {
            case 1:
                if (op == 1)
                    crearequip(cam);
            case 2:
                if (op == 2)
                    cam.equips();
            case 3:
                if (op == 3)
                    esborrarequips(cam);
            case 4:
                if (op == 4)
                    jugequi(cam);
        }
        if (op == 5)
            menu2(cam,a);
    }

    public static void menuITEMS(camara cam,File a) {
        System.out.println("1.3.1 Crear item\n1.3.2 Mostrar items\n1.3.3 Esborrar items\n1.3.4 Assignar items a un jugador\n1.3.5 Eixir");
        Scanner opcio = new Scanner(System.in);
        int nummenu = 3;
        int op = opcio.nextInt();
        switch (op) {
            case 1:
                if (op == 1)
                    crearitem(cam);
            case 2:
                if (op == 2)
                    cam.items(cam);
            case 3:
                if (op == 3)
                    esborraritems(cam);
            case 4:
                if (op == 4)
                    itemequi(cam);
            case 5:
                if (op == 5)
                    menu2(cam,a);


        }
    }

    public static void menu2(camara cam,File a) {
        System.out.println("1.1 Gestió jugadors\n1.2 Gestió equips\n1.3 Gestió Objectes\n1.4 Eixir\n");
        Scanner opcio = new Scanner(System.in);
        int nummenu = 2;
        int op = opcio.nextInt();
        switch (op) {
            case 1:
                if (op == 1)
                    menuJUGADORS(cam,a);
            case 2:
                if (op == 2)
                    menuEquips(cam,a);
            case 3:
                if (op == 3)
                    menuITEMS(cam,a);
            case 4:
                if (op == 4)
                    menuprinc(cam,a);
        }
    }

    public static boolean menuprinc(camara cam,File a) {
        System.out.println("*****JOC DE ROL*****\n1. Configuració\n2. Jugar\n3. Eixir\n");
        int nummenu = 2;
        Scanner opcio = new Scanner(System.in);
        int op = opcio.nextInt();
        switch (op) {
            case 1:
                if (op == 1)
                    menu2(cam,a);
                return true;
            case 2:

                if (op == 2)
                    jugar(cam,a);
                return true;
            case 3:
                if (op == 3) {
                    return false;

                }
        }
        return true;
    }

    public static void jugar(camara cam,File a) {
        if (cam.getJugadors().size() == 0) {
            System.out.println("No pots jugar, has de crear almeys dos jugadors");
            menuprinc(cam,a);
        } else {
            int i = 0;
            int x = 0;
            if (cam.getJugadors().size() != 0) {
                while (x == 0) {
                    while (i != cam.getJugadors().size()) {

                        System.out.println("Li toca al jugador " + cam.getJugadors().get(i).getNom());
                        System.out.println("A qui vols atacar ");
                        Scanner opcio = new Scanner(System.in);
                        String NOM = opcio.nextLine();
                        try {
                            cam.getJugadors().get(i).attack(cam.getJugadors().get(i));
                        } catch (Exception e) {
                            System.out.println("no pots atacarte a tu mateixa");

                        }
                        cam.getJugadors().get(i).attack(traureEq(NOM, cam));
                        if (cam.getJugadors().get(i).getHP() <= 0) {
                            cam.getJugadors().remove(cam.getJugadors().get(i));
                        }
                        if (traureEq(NOM, cam).getHP() <= 0) {
                            cam.getJugadors().remove(traureEq(NOM, cam));
                        }
                        if (cam.getJugadors().size() == 1) {
                            break;

                        }
                        i = i + 1;


                    }
                    if (i + 1 == cam.getJugadors().size()) {
                        System.out.println("No se ha trobat el nom");

                    }
                    i = i + 1;
                    if (cam.getJugadors().size() == 1) {
                        x = 1;
                    }

                }
                System.out.println("EL GUANYADOR ES " + cam.getJugadors().get(0));
                try {
                    FileWriter br = new FileWriter(a);
                    BufferedWriter brb = new BufferedWriter(br);
                    brb.write(cam.getJugadors().get(0).toString());


                    brb.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }


            }
        }

    }

    public static void main(String[] args) {
        boolean x = false;
        File d = new File("ranking.dat");
        ArrayList<Player> Items = new ArrayList<Player>();
        camara cam = new camara();
        while (!x) {
            if (!menuprinc(cam,d)) {
                x = true;
            }
            ;
        }
        File a = new File("players.dat");
        File b = new File("teams.dat");
        File c = new File("items.dat");
        try {
            FileWriter ar = new FileWriter(a);
            BufferedWriter arb = new BufferedWriter(ar);
            int i = 0;
            if (cam.getJugadors().size() != 0) {

                while (i != cam.getJugadors().size()) {
                         arb.write(cam.getJugadors().get(i).toString());
                         arb.newLine();
                }
                if (i + 1 == cam.getJugadors().size()) {

                }
                i = i + 1;
            }
            arb.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        try {
            FileWriter br = new FileWriter(b);
            BufferedWriter brb = new BufferedWriter(br);
            int i = 0;
            if (cam.getPlayers2().size() != 0) {

                while (i != cam.getPlayers2().size()) {
                    brb.write(cam.getPlayers2().get(i).toString());
                    brb.newLine();
                }
                i = i + 1;
            }
            brb.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        try {
            FileWriter br = new FileWriter(c);
            BufferedWriter brb = new BufferedWriter(br);
            int i = 0;
            if (cam.getPlayers2().size() != 0) {

                while (i != cam.getPlayers2().size()) {
                    brb.write(cam.getPlayers2().get(i).toString());
                    brb.newLine();
                }
                i = i + 1;
            }
            brb.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        }





        }




