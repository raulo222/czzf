package joc;

import jdk.swing.interop.SwingInterOpUtils;

import java.util.ArrayList;

public class camara {
    static ArrayList<Team> Players2 = new ArrayList<Team>();
    static ArrayList<Item> Items = new ArrayList<Item>();
    static ArrayList<Player> Jugadors = new ArrayList<Player>();
    static ArrayList<Player> JugadorsM = new ArrayList<Player>();
    public camara(){
    }

    public ArrayList<Team> getPlayers2() {
        return Players2;
    }
    public void tString() {
        System.out.println("//////////////JUGADORS///////////////////////");
        int i = -1;
        if (Jugadors.size()!=0) {

            while (i != Jugadors.size()) {
                i = i + 1;
                System.out.println("Jugador num "
                        + (i + 1) + "  " + Jugadors.get(i));
                if (i + 1 == Jugadors.size()) {
                    break;
                }
            }
        }
        else System.out.println("esta vuida");
        }
    public void equips() {
        System.out.println("//////////////EQUIPS///////////////////////");
        int i = -1;
        if (Players2.size()!=0) {

            while (i != Players2.size()) {
                i = i + 1;
                System.out.println("Equip num " +i+1);
                Players2.get(i).tString();

                if (i + 1 == Players2.size()) {
                    break;
                }
            }
        }
        else System.out.println("esta vuida");
    }

    public void delplayer(String nom) {
        int i = -1;
        if (Jugadors.size() != 0) {

            while (i != Jugadors.size()) {
                i = i + 1;
                if (Jugadors.get(i).getNom().equals(nom)) {
                    Jugadors.remove(Jugadors.get(i));
                    JugadorsM.remove(JugadorsM.get(i));
                }
                if (i + 1 == Jugadors.size()) {
                    break;
                }
            }
        }
    }
        public void delequip(String nom) {
            int i = -1;
            if (Players2.size() != 0) {

                while (i != Players2.size()) {
                    i = i + 1;
                    if (Players2.get(i).getName().equals(nom)) {
                        Players2.remove(Players2.get(i));
                    }
                    if (i + 1 == Jugadors.size()) {
                        break;
                    }
                }
            }
        }
    public void delitem(String nom) {
        int i = -1;
        if (Items.size() != 0) {

            while (i != Items.size()) {
                i = i + 1;
                if ( Items.get(i).getNom().equals(nom)) {
                    Items.remove(Items.get(i));
                }
                if (i + 1 == Jugadors.size()) {
                    break;
                }
            }
        }
    }
            public void items(camara cam){
                int i = -1;
                if (Items.size()!=0) {

                    while (i != Items.size()) {
                        i = i + 1;
                            System.out.println(Items.get(i));
                        if (i + 1 == Items.size()) {
                            break;
                        }
                    }
                }


    }
    public void addplayer(Player X){
        Jugadors.add(X);
        JugadorsM.add(X);
    }
    public void addteam(Team X){
        getPlayers2().add(X);

    }
    public void additem(Item X){
        getItems().add(X);

    }

    public ArrayList<Item> getItems() {
        return Items;
    }


    public ArrayList<Player> getJugadors() {
        return Jugadors;
    }

    public void setJugadors(ArrayList<Player> jugadors) {
        Jugadors = jugadors;
    }
}

