package joc;

public class excepcions {
}


abstract class ExcepcioJocRol extends Exception {

    @Override
    public abstract String getMessage();



    public static class excJugadorMort extends ExcepcioJocRol{

        @Override
        public String getMessage() {
            return "EL JUGADOR ESTA MORT!!\n";
        }

    }
    public static class excAttackMe extends ExcepcioJocRol {

        @Override
        public String getMessage() {
            return ("No pots atacarte a tu mateix!!\n");
        }
    }
    public static class excAttackJugadorMort extends ExcepcioJocRol {

        @Override
        public String getMessage() {
            return "ERROR NO ES POT ATACAR A UN JUGADOR MORT!!\n";
        }
    }
        public static class excRepeatTeamPlayer extends ExcepcioJocRol{

            @Override
            public String getMessage() {
                return "EL JUGADOR JA PERTANY A AQUEST EQUIP!!\n";
            }

        }
    }


